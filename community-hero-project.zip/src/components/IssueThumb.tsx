import { useEffect, useState } from "react";
import { getSignedImageUrl } from "@/lib/issues";
import { ImageIcon } from "lucide-react";

export function IssueThumb({ path, alt, className }: { path: string | null; alt: string; className?: string }) {
  const [url, setUrl] = useState<string | null>(null);
  useEffect(() => {
    let active = true;
    getSignedImageUrl(path).then((u) => {
      if (active) setUrl(u);
    });
    return () => {
      active = false;
    };
  }, [path]);

  if (!url) {
    return (
      <div className={`flex h-full w-full items-center justify-center bg-muted ${className ?? ""}`}>
        <ImageIcon className="h-8 w-8 text-muted-foreground/40" />
      </div>
    );
  }
  return <img src={url} alt={alt} className={`h-full w-full object-cover ${className ?? ""}`} loading="lazy" />;
}
