import { useEffect, useState } from "react";
import { ShieldCheck, Sparkles, MapPin } from "lucide-react";

export function SplashScreen({ onDone }: { onDone: () => void }) {
  const [exiting, setExiting] = useState(false);

  useEffect(() => {
    const t1 = setTimeout(() => setExiting(true), 2400);
    const t2 = setTimeout(() => onDone(), 3000);
    return () => {
      clearTimeout(t1);
      clearTimeout(t2);
    };
  }, [onDone]);

  return (
    <div
      className={`fixed inset-0 z-[100] flex items-center justify-center bg-gradient-hero transition-opacity duration-500 ${
        exiting ? "opacity-0" : "opacity-100"
      }`}
    >
      {/* Orbit rings */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
        <div className="relative w-[600px] h-[600px] max-w-[90vw] max-h-[90vw]">
          <div className="absolute inset-0 rounded-full border border-white/10 animate-splash-orbit" />
          <div
            className="absolute inset-8 rounded-full border border-white/10 animate-splash-orbit"
            style={{ animationDirection: "reverse", animationDuration: "12s" }}
          />
          <div
            className="absolute inset-16 rounded-full border border-white/5 animate-splash-orbit"
            style={{ animationDuration: "20s" }}
          />
          {/* Floating dots */}
          {[
            { top: "10%", left: "50%", icon: MapPin },
            { top: "50%", left: "12%", icon: ShieldCheck },
            { top: "78%", left: "82%", icon: Sparkles },
          ].map(({ top, left, icon: Icon }, i) => (
            <div
              key={i}
              className="absolute -translate-x-1/2 -translate-y-1/2 animate-splash-pulse"
              style={{ top, left, animationDelay: `${i * 0.4}s` }}
            >
              <div className="relative">
                <span className="absolute inset-0 rounded-full bg-signal/40 animate-ping-soft" />
                <span className="relative flex h-10 w-10 items-center justify-center rounded-full bg-signal text-signal-foreground shadow-glow">
                  <Icon className="h-5 w-5" />
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Center logo */}
      <div className="relative text-center px-6 animate-float-up">
        <div className="mx-auto mb-6 flex h-20 w-20 items-center justify-center rounded-2xl bg-gradient-signal shadow-glow">
          <ShieldCheck className="h-10 w-10 text-signal-foreground" strokeWidth={2.2} />
        </div>
        <h1 className="font-display text-4xl md:text-6xl font-bold text-white tracking-tight">
          Community Hero
        </h1>
        <p
          className="mt-3 text-base md:text-lg text-white/70 font-medium animate-float-up"
          style={{ animationDelay: "0.3s" }}
        >
          AI-powered solution for better communities
        </p>

        <div
          className="mt-10 flex justify-center gap-1.5 animate-float-up"
          style={{ animationDelay: "0.6s" }}
        >
          {[0, 1, 2].map((i) => (
            <span
              key={i}
              className="h-1.5 w-1.5 rounded-full bg-signal animate-splash-pulse"
              style={{ animationDelay: `${i * 0.2}s` }}
            />
          ))}
        </div>
      </div>
    </div>
  );
}
