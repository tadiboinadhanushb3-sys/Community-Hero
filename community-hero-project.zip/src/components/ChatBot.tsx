import { useState, useRef, useEffect } from "react";
import { Bot, Send, X, Loader2, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useServerFn } from "@tanstack/react-start";
import { chatWithAssistant } from "@/lib/ai.functions";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

type Msg = { role: "user" | "assistant"; content: string };

export function ChatBot() {
  const [open, setOpen] = useState(false);
  const [messages, setMessages] = useState<Msg[]>([
    {
      role: "assistant",
      content:
        "Hi! I'm your Community Hero assistant. Ask me anything — *'what's urgent nearby?'*, *'how do I report a pothole?'*, or *'show unresolved issues'*.",
    },
  ]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const chatFn = useServerFn(chatWithAssistant);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages, open]);

  async function handleSend(e: React.FormEvent) {
    e.preventDefault();
    const text = input.trim();
    if (!text || loading) return;
    const next: Msg[] = [...messages, { role: "user" as const, content: text }];
    setMessages(next);
    setInput("");
    setLoading(true);

    try {
      // Gather lightweight context
      const [allRes, openRes, urgentRes, recent] = await Promise.all([
        supabase.from("issues").select("id", { count: "exact", head: true }),
        supabase.from("issues").select("id", { count: "exact", head: true }).neq("status", "resolved"),
        supabase.from("issues").select("id", { count: "exact", head: true }).in("severity", ["high", "critical"]).neq("status", "resolved"),
        supabase.from("issues").select("title,category,severity,status,address").order("created_at", { ascending: false }).limit(8),
      ]);

      const res = await chatFn({
        data: {
          messages: next.map((m) => ({ role: m.role, content: m.content })),
          context: {
            totalIssues: allRes.count ?? 0,
            activeIssues: openRes.count ?? 0,
            resolvedIssues: (allRes.count ?? 0) - (openRes.count ?? 0),
            urgentIssues: urgentRes.count ?? 0,
            recentIssues: (recent.data ?? []).map((r) => ({
              title: r.title,
              category: r.category,
              severity: r.severity,
              status: r.status,
              address: r.address,
            })),
          },
        },
      });
      if ("error" in res) {
        toast.error(res.error);
        setMessages(next);
      } else {
        setMessages([...next, { role: "assistant", content: res.reply }]);
      }
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Chat failed");
    } finally {
      setLoading(false);
    }
  }

  return (
    <>
      <button
        onClick={() => setOpen((o) => !o)}
        className="fixed bottom-20 right-4 md:bottom-6 md:right-6 z-40 flex h-14 w-14 items-center justify-center rounded-full bg-gradient-signal text-signal-foreground shadow-glow hover:scale-105 transition-transform"
        aria-label="Open AI assistant"
      >
        {open ? <X className="h-6 w-6" /> : <Bot className="h-6 w-6" />}
      </button>

      {open && (
        <div className="fixed bottom-36 right-4 md:bottom-24 md:right-6 z-40 w-[calc(100vw-2rem)] max-w-sm rounded-2xl bg-card shadow-elevated border overflow-hidden animate-float-up flex flex-col" style={{ height: "60vh", maxHeight: "560px" }}>
          <div className="flex items-center gap-2 border-b p-3 bg-gradient-hero text-white">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-signal text-signal-foreground">
              <Sparkles className="h-4 w-4" />
            </div>
            <div className="flex-1">
              <p className="font-display font-semibold text-sm">Community AI</p>
              <p className="text-[10px] text-white/60">Powered by Gemini</p>
            </div>
          </div>

          <div ref={scrollRef} className="flex-1 overflow-y-auto p-3 space-y-3">
            {messages.map((m, i) => (
              <div key={i} className={`flex ${m.role === "user" ? "justify-end" : "justify-start"}`}>
                <div
                  className={`max-w-[85%] rounded-2xl px-3.5 py-2 text-sm leading-relaxed whitespace-pre-wrap ${
                    m.role === "user"
                      ? "bg-primary text-primary-foreground rounded-br-sm"
                      : "bg-secondary text-secondary-foreground rounded-bl-sm"
                  }`}
                >
                  {m.content}
                </div>
              </div>
            ))}
            {loading && (
              <div className="flex items-center gap-2 text-xs text-muted-foreground px-2">
                <Loader2 className="h-3 w-3 animate-spin" /> Thinking...
              </div>
            )}
          </div>

          <form onSubmit={handleSend} className="border-t p-2 flex gap-2">
            <input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Ask about your community..."
              className="flex-1 rounded-lg bg-secondary px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-ring"
              disabled={loading}
              maxLength={500}
            />
            <Button type="submit" size="icon" disabled={loading || !input.trim()}>
              <Send className="h-4 w-4" />
            </Button>
          </form>
        </div>
      )}
    </>
  );
}
