import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState, useRef } from "react";
import { useServerFn } from "@tanstack/react-start";
import { useMutation } from "@tanstack/react-query";
import { AppShell } from "@/components/AppShell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  Camera, Upload, MapPin, Sparkles, Loader2, AlertTriangle, CheckCircle2, X, Wand2,
} from "lucide-react";
import { analyzeIssueImage, type AiAnalysis } from "@/lib/ai.functions";
import { supabase } from "@/integrations/supabase/client";
import { CATEGORY_META, SEVERITY_META, type IssueCategory, type IssueSeverity } from "@/lib/issues";
import { toast } from "sonner";
import { useAuth } from "@/lib/auth-context";

export const Route = createFileRoute("/_authenticated/report")({
  head: () => ({ meta: [{ title: "Report an issue — Community Hero" }] }),
  component: ReportPage,
});

async function fileToDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

function ReportPage() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const analyzeFn = useServerFn(analyzeIssueImage);
  const fileRef = useRef<HTMLInputElement>(null);

  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [userNote, setUserNote] = useState("");
  const [analysis, setAnalysis] = useState<AiAnalysis | null>(null);

  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [category, setCategory] = useState<IssueCategory>("other");
  const [severity, setSeverity] = useState<IssueSeverity>("medium");
  const [address, setAddress] = useState("");
  const [coords, setCoords] = useState<{ lat: number; lng: number } | null>(null);
  const [locLoading, setLocLoading] = useState(false);

  function handleFile(f: File | null) {
    if (!f) return;
    if (f.size > 8 * 1024 * 1024) return toast.error("Image must be under 8MB");
    setFile(f);
    setAnalysis(null);
    const reader = new FileReader();
    reader.onload = () => setPreview(reader.result as string);
    reader.readAsDataURL(f);
  }

  function captureLocation() {
    if (!navigator.geolocation) return toast.error("Geolocation not supported");
    setLocLoading(true);
    navigator.geolocation.getCurrentPosition(
      async (pos) => {
        setCoords({ lat: pos.coords.latitude, lng: pos.coords.longitude });
        // Reverse-geocode via Google
        try {
          const apiKey = import.meta.env.VITE_GOOGLE_MAPS_API_KEY;
          if (apiKey) {
            const r = await fetch(
              `https://maps.googleapis.com/maps/api/geocode/json?latlng=${pos.coords.latitude},${pos.coords.longitude}&key=${apiKey}`,
            );
            const d = await r.json();
            if (d.results?.[0]) setAddress(d.results[0].formatted_address);
          } else {
            setAddress(`${pos.coords.latitude.toFixed(5)}, ${pos.coords.longitude.toFixed(5)}`);
          }
        } catch {
          setAddress(`${pos.coords.latitude.toFixed(5)}, ${pos.coords.longitude.toFixed(5)}`);
        }
        setLocLoading(false);
        toast.success("Location captured");
      },
      (err) => {
        setLocLoading(false);
        toast.error(err.message || "Could not get location");
      },
      { enableHighAccuracy: true, timeout: 10000 },
    );
  }

  const analyzeMutation = useMutation({
    mutationFn: async () => {
      if (!file) throw new Error("Upload an image first");
      const dataUrl = await fileToDataUrl(file);
      const res = await analyzeFn({ data: { imageDataUrl: dataUrl, userNote: userNote || undefined } });
      if ("error" in res) throw new Error(res.error);
      return res.analysis;
    },
    onSuccess: (a) => {
      setAnalysis(a);
      setTitle(a.title);
      setDescription(a.complaint_text);
      setCategory(a.category);
      setSeverity(a.severity);
      toast.success("AI analysis complete");
    },
    onError: (e) => toast.error(e instanceof Error ? e.message : "Analysis failed"),
  });

  const submitMutation = useMutation({
    mutationFn: async () => {
      if (!user) throw new Error("Sign in required");
      if (!title.trim() || !description.trim()) throw new Error("Title and description required");

      let imagePath: string | null = null;
      if (file) {
        const ext = file.name.split(".").pop() || "jpg";
        const path = `${user.id}/${Date.now()}.${ext}`;
        const { error: upErr } = await supabase.storage.from("issue-images").upload(path, file, {
          cacheControl: "3600",
          upsert: false,
        });
        if (upErr) throw upErr;
        imagePath = path;
      }

      const { data, error } = await supabase
        .from("issues")
        .insert({
          reporter_id: user.id,
          title: title.trim().slice(0, 120),
          description: description.trim(),
          category,
          severity,
          status: "reported",
          address: address || null,
          latitude: coords?.lat ?? null,
          longitude: coords?.lng ?? null,
          image_url: imagePath,
          ai_analysis: analysis ? (analysis as any) : null,
        })
        .select("id")
        .single();
      if (error) throw error;
      return data.id as string;
    },
    onSuccess: (id) => {
      toast.success("Report submitted!");
      navigate({ to: "/issues/$id", params: { id } });
    },
    onError: (e) => toast.error(e instanceof Error ? e.message : "Submission failed"),
  });

  return (
    <AppShell>
      <div className="max-w-3xl mx-auto">
        <div className="mb-6">
          <h1 className="font-display text-3xl font-bold">Report a civic issue</h1>
          <p className="text-muted-foreground mt-1">Upload a photo — our AI drafts the complaint for you.</p>
        </div>

        <div className="space-y-6">
          {/* Step 1: Image */}
          <Card step={1} title="Photo evidence" subtitle="A clear photo helps AI assess severity">
            {!preview ? (
              <label className="flex flex-col items-center justify-center gap-3 rounded-2xl border-2 border-dashed border-border bg-secondary/40 p-10 cursor-pointer hover:border-primary hover:bg-secondary transition">
                <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-signal shadow-glow">
                  <Camera className="h-7 w-7 text-signal-foreground" />
                </div>
                <div className="text-center">
                  <p className="font-semibold">Tap to upload or take a photo</p>
                  <p className="text-xs text-muted-foreground mt-1">JPG, PNG up to 8MB</p>
                </div>
                <input
                  ref={fileRef}
                  type="file"
                  accept="image/*"
                  capture="environment"
                  className="hidden"
                  onChange={(e) => handleFile(e.target.files?.[0] ?? null)}
                />
              </label>
            ) : (
              <div className="relative rounded-2xl overflow-hidden">
                <img src={preview} alt="preview" className="w-full max-h-96 object-cover" />
                <button
                  onClick={() => {
                    setFile(null);
                    setPreview(null);
                    setAnalysis(null);
                  }}
                  className="absolute top-3 right-3 flex h-9 w-9 items-center justify-center rounded-full bg-background/90 shadow-card hover:bg-background"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>
            )}

            <div className="mt-4 space-y-2">
              <Label htmlFor="note">Optional note for the AI</Label>
              <Textarea
                id="note"
                value={userNote}
                onChange={(e) => setUserNote(e.target.value)}
                placeholder="e.g., 'This pothole appeared after last week's storm'"
                rows={2}
                maxLength={500}
              />
            </div>

            <Button
              onClick={() => analyzeMutation.mutate()}
              disabled={!file || analyzeMutation.isPending}
              className="mt-4 w-full bg-gradient-signal text-signal-foreground shadow-glow"
              size="lg"
            >
              {analyzeMutation.isPending ? (
                <><Loader2 className="h-4 w-4 animate-spin" /> Analyzing with Gemini...</>
              ) : (
                <><Wand2 className="h-4 w-4" /> {analysis ? "Re-analyze" : "Analyze with AI"}</>
              )}
            </Button>
          </Card>

          {/* AI Analysis Card */}
          {analysis && (
            <div className="rounded-2xl border-2 border-signal/40 bg-gradient-to-br from-signal/5 to-transparent p-5 animate-float-up">
              <div className="flex items-center gap-2 mb-3">
                <Sparkles className="h-5 w-5 text-signal" />
                <h3 className="font-display font-bold">AI Triage Report</h3>
              </div>
              <div className="grid sm:grid-cols-2 gap-3 mb-3">
                <Tag label="Category" value={`${CATEGORY_META[analysis.category].emoji} ${CATEGORY_META[analysis.category].label}`} />
                <Tag label="Severity" value={SEVERITY_META[analysis.severity].label} color={SEVERITY_META[analysis.severity].color} />
                <Tag label="Est. repair time" value={analysis.estimated_repair_time} />
                <Tag label="Title" value={analysis.title} />
              </div>
              {analysis.risks.length > 0 && (
                <div className="mb-3">
                  <p className="text-xs font-semibold text-muted-foreground mb-1">SAFETY RISKS</p>
                  <ul className="text-sm space-y-1">
                    {analysis.risks.map((r, i) => (
                      <li key={i} className="flex gap-2"><AlertTriangle className="h-4 w-4 text-severity-high shrink-0 mt-0.5" /> {r}</li>
                    ))}
                  </ul>
                </div>
              )}
              <div>
                <p className="text-xs font-semibold text-muted-foreground mb-1">RECOMMENDATION</p>
                <p className="text-sm flex gap-2"><CheckCircle2 className="h-4 w-4 text-status-resolved shrink-0 mt-0.5" /> {analysis.recommendation}</p>
              </div>
            </div>
          )}

          {/* Step 2: Details */}
          <Card step={2} title="Issue details" subtitle="Confirm or edit the AI-drafted details">
            <div className="space-y-4">
              <div>
                <Label htmlFor="title">Title</Label>
                <Input id="title" value={title} onChange={(e) => setTitle(e.target.value)} maxLength={120} placeholder="Short summary of the issue" />
              </div>
              <div className="grid sm:grid-cols-2 gap-4">
                <div>
                  <Label>Category</Label>
                  <Select value={category} onValueChange={(v) => setCategory(v as IssueCategory)}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {(Object.keys(CATEGORY_META) as IssueCategory[]).map((k) => (
                        <SelectItem key={k} value={k}>{CATEGORY_META[k].emoji} {CATEGORY_META[k].label}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label>Severity</Label>
                  <Select value={severity} onValueChange={(v) => setSeverity(v as IssueSeverity)}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {(Object.keys(SEVERITY_META) as IssueSeverity[]).map((k) => (
                        <SelectItem key={k} value={k}>{SEVERITY_META[k].label}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div>
                <Label htmlFor="desc">Complaint description</Label>
                <Textarea id="desc" value={description} onChange={(e) => setDescription(e.target.value)} rows={8} maxLength={2000} />
              </div>
            </div>
          </Card>

          {/* Step 3: Location */}
          <Card step={3} title="Location" subtitle="So authorities can find it">
            <div className="flex flex-col sm:flex-row gap-2">
              <Input value={address} onChange={(e) => setAddress(e.target.value)} placeholder="Street, area, landmark" />
              <Button type="button" variant="outline" onClick={captureLocation} disabled={locLoading}>
                {locLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : <MapPin className="h-4 w-4" />}
                Use GPS
              </Button>
            </div>
            {coords && (
              <p className="text-xs text-muted-foreground mt-2">
                📍 {coords.lat.toFixed(5)}, {coords.lng.toFixed(5)}
              </p>
            )}
          </Card>

          <Button
            onClick={() => submitMutation.mutate()}
            disabled={submitMutation.isPending || !title || !description}
            size="lg"
            className="w-full"
          >
            {submitMutation.isPending ? (
              <><Loader2 className="h-4 w-4 animate-spin" /> Submitting...</>
            ) : (
              <><Upload className="h-4 w-4" /> Submit report</>
            )}
          </Button>
        </div>
      </div>
    </AppShell>
  );
}

function Card({ step, title, subtitle, children }: { step: number; title: string; subtitle: string; children: React.ReactNode }) {
  return (
    <div className="rounded-2xl bg-card border shadow-card p-5">
      <div className="flex items-start gap-3 mb-4">
        <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary text-primary-foreground text-sm font-bold font-display">
          {step}
        </div>
        <div>
          <h2 className="font-display font-bold text-lg leading-tight">{title}</h2>
          <p className="text-xs text-muted-foreground">{subtitle}</p>
        </div>
      </div>
      {children}
    </div>
  );
}

function Tag({ label, value, color }: { label: string; value: string; color?: string }) {
  return (
    <div className="rounded-lg bg-card border p-2.5">
      <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-semibold">{label}</p>
      <p className="text-sm font-semibold mt-0.5" style={color ? { color } : undefined}>{value}</p>
    </div>
  );
}
