import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { AppShell } from "@/components/AppShell";
import { supabase } from "@/integrations/supabase/client";
import { CATEGORY_META, SEVERITY_META, STATUS_META, formatRelativeTime, getSignedImageUrl, type IssueStatus } from "@/lib/issues";
import { useAuth } from "@/lib/auth-context";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ThumbsUp, MapPin, Send, ArrowLeft, CheckCircle2, Sparkles, AlertTriangle, Loader2 } from "lucide-react";
import { useEffect, useState } from "react";
import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated/issues/$id")({
  head: () => ({ meta: [{ title: "Issue — Community Hero" }] }),
  component: IssueDetail,
});

function IssueDetail() {
  const { id } = Route.useParams();
  const { user, isAdmin } = useAuth();
  const qc = useQueryClient();
  const [comment, setComment] = useState("");
  const [imgUrl, setImgUrl] = useState<string | null>(null);

  const { data: issue } = useQuery({
    queryKey: ["issue", id],
    queryFn: async () => {
      const { data, error } = await supabase.from("issues").select("*").eq("id", id).single();
      if (error) throw error;
      return data;
    },
  });

  const { data: hasVerified } = useQuery({
    queryKey: ["verified", id, user?.id],
    enabled: !!user,
    queryFn: async () => {
      const { data } = await supabase.from("verifications").select("id").eq("issue_id", id).eq("user_id", user!.id).maybeSingle();
      return !!data;
    },
  });

  const { data: comments } = useQuery({
    queryKey: ["comments", id],
    queryFn: async () => {
      const { data: rows } = await supabase.from("comments").select("*").eq("issue_id", id).order("created_at", { ascending: true });
      const userIds = Array.from(new Set((rows ?? []).map((r) => r.user_id)));
      const { data: profs } = userIds.length
        ? await supabase.from("profiles").select("id,full_name").in("id", userIds)
        : { data: [] };
      const pMap = new Map((profs ?? []).map((p) => [p.id, p.full_name]));
      return (rows ?? []).map((r) => ({ ...r, author: pMap.get(r.user_id) ?? "Citizen" }));
    },
  });



  const { data: updates } = useQuery({
    queryKey: ["updates", id],
    queryFn: async () => {
      const { data } = await supabase.from("status_updates").select("*").eq("issue_id", id).order("created_at", { ascending: true });
      return data ?? [];
    },
  });

  useEffect(() => {
    if (issue?.image_url) getSignedImageUrl(issue.image_url).then(setImgUrl);
  }, [issue?.image_url]);

  const verifyMutation = useMutation({
    mutationFn: async () => {
      if (!user) throw new Error("Sign in to verify");
      if (hasVerified) {
        await supabase.from("verifications").delete().eq("issue_id", id).eq("user_id", user.id);
      } else {
        await supabase.from("verifications").insert({ issue_id: id, user_id: user.id });
      }
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["verified", id] });
      qc.invalidateQueries({ queryKey: ["issue", id] });
    },
    onError: (e) => toast.error(e instanceof Error ? e.message : "Failed"),
  });

  const commentMutation = useMutation({
    mutationFn: async () => {
      if (!user) throw new Error("Sign in");
      if (!comment.trim()) return;
      const { error } = await supabase.from("comments").insert({ issue_id: id, user_id: user.id, content: comment.trim() });
      if (error) throw error;
    },
    onSuccess: () => {
      setComment("");
      qc.invalidateQueries({ queryKey: ["comments", id] });
    },
    onError: (e) => toast.error(e instanceof Error ? e.message : "Comment failed"),
  });

  const statusMutation = useMutation({
    mutationFn: async (newStatus: IssueStatus) => {
      if (!user) throw new Error("Sign in");
      const { error } = await supabase.from("issues").update({ status: newStatus, updated_at: new Date().toISOString() }).eq("id", id);
      if (error) throw error;
      await supabase.from("status_updates").insert({ issue_id: id, changed_by: user.id, to_status: newStatus, from_status: issue?.status, note: `Status changed to ${newStatus}` });
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["issue", id] });
      qc.invalidateQueries({ queryKey: ["updates", id] });
      toast.success("Status updated");
    },
    onError: (e) => toast.error(e instanceof Error ? e.message : "Failed"),
  });

  if (!issue) {
    return (
      <AppShell>
        <div className="flex items-center justify-center py-20"><Loader2 className="h-6 w-6 animate-spin" /></div>
      </AppShell>
    );
  }

  const cat = CATEGORY_META[issue.category];
  const sev = SEVERITY_META[issue.severity];
  const stat = STATUS_META[issue.status];
  const aiData = issue.ai_analysis as null | {
    risks?: string[];
    recommendation?: string;
    estimated_repair_time?: string;
  };

  return (
    <AppShell>
      <Link to="/issues" className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground mb-4">
        <ArrowLeft className="h-4 w-4" /> Back to issues
      </Link>

      <div className="grid lg:grid-cols-[1.5fr,1fr] gap-6">
        <div>
          {imgUrl && (
            <div className="rounded-2xl overflow-hidden mb-4 bg-muted">
              <img src={imgUrl} alt={issue.title} className="w-full max-h-[480px] object-cover" />
            </div>
          )}

          <div className="flex flex-wrap gap-2 mb-3">
            <span className="rounded-full bg-secondary px-3 py-1 text-xs font-semibold">{cat.emoji} {cat.label}</span>
            <span className="rounded-full px-3 py-1 text-xs font-semibold text-white" style={{ backgroundColor: sev.color }}>{sev.label} severity</span>
            <span className="rounded-full px-3 py-1 text-xs font-semibold text-white" style={{ backgroundColor: stat.color }}>{stat.label}</span>
          </div>

          <h1 className="font-display text-2xl md:text-3xl font-bold">{issue.title}</h1>
          {issue.address && (
            <p className="mt-2 text-sm text-muted-foreground inline-flex items-center gap-1.5">
              <MapPin className="h-4 w-4" /> {issue.address}
            </p>
          )}
          <p className="mt-4 text-sm leading-relaxed whitespace-pre-wrap text-foreground/90">{issue.description}</p>

          {aiData && (
            <div className="mt-6 rounded-2xl border border-signal/30 bg-signal/5 p-4">
              <div className="flex items-center gap-2 mb-3"><Sparkles className="h-4 w-4 text-signal" /><h3 className="font-display font-bold text-sm">AI triage notes</h3></div>
              {aiData.risks && aiData.risks.length > 0 && (
                <ul className="text-sm space-y-1 mb-2">
                  {aiData.risks.map((r, i) => (
                    <li key={i} className="flex gap-2"><AlertTriangle className="h-4 w-4 text-severity-high shrink-0 mt-0.5" />{r}</li>
                  ))}
                </ul>
              )}
              {aiData.recommendation && <p className="text-sm flex gap-2"><CheckCircle2 className="h-4 w-4 text-status-resolved shrink-0 mt-0.5" />{aiData.recommendation}</p>}
            </div>
          )}

          {/* Comments */}
          <div className="mt-8">
            <h2 className="font-display font-bold text-lg mb-3">Community discussion</h2>
            <div className="space-y-3 mb-4">
              {(comments ?? []).map((c: any) => (
                <div key={c.id} className="rounded-2xl bg-card border p-3">
                  <div className="flex items-center justify-between mb-1">
                    <p className="text-sm font-semibold">{c.author}</p>
                    <p className="text-xs text-muted-foreground">{formatRelativeTime(c.created_at)}</p>
                  </div>
                  <p className="text-sm">{c.content}</p>
                </div>
              ))}
              {comments?.length === 0 && <p className="text-sm text-muted-foreground">Be the first to comment.</p>}
            </div>
            <div className="flex gap-2">
              <Textarea value={comment} onChange={(e) => setComment(e.target.value)} placeholder="Share an update or observation..." rows={2} maxLength={1000} />
              <Button onClick={() => commentMutation.mutate()} disabled={commentMutation.isPending || !comment.trim()}>
                <Send className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>

        {/* Sidebar */}
        <aside className="space-y-4">
          <div className="rounded-2xl bg-card border shadow-card p-5">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs uppercase tracking-wider text-muted-foreground font-semibold">Verifications</p>
                <p className="font-display text-3xl font-bold mt-1">{issue.verification_count}</p>
              </div>
              <Button
                variant={hasVerified ? "secondary" : "default"}
                onClick={() => verifyMutation.mutate()}
                disabled={verifyMutation.isPending}
                className={hasVerified ? "" : "bg-gradient-signal text-signal-foreground shadow-glow"}
              >
                <ThumbsUp className="h-4 w-4" /> {hasVerified ? "Verified" : "Verify"}
              </Button>
            </div>
            <p className="mt-3 text-xs text-muted-foreground">Reported {formatRelativeTime(issue.created_at)}</p>
          </div>

          {isAdmin && (
            <div className="rounded-2xl bg-card border shadow-card p-5">
              <p className="text-xs uppercase tracking-wider text-muted-foreground font-semibold mb-2">Admin controls</p>
              <Select value={issue.status} onValueChange={(v) => statusMutation.mutate(v as IssueStatus)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {(Object.keys(STATUS_META) as IssueStatus[]).map((k) => (
                    <SelectItem key={k} value={k}>{STATUS_META[k].label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )}

          <div className="rounded-2xl bg-card border shadow-card p-5">
            <p className="text-xs uppercase tracking-wider text-muted-foreground font-semibold mb-3">Timeline</p>
            <ol className="space-y-3">
              <TimelineItem time={issue.created_at} title="Reported" color={STATUS_META.reported.color} />
              {(updates ?? []).map((u: any) => (
                <TimelineItem
                  key={u.id}
                  time={u.created_at}
                  title={STATUS_META[u.status as IssueStatus]?.label ?? u.status}
                  note={u.note}
                  color={STATUS_META[u.status as IssueStatus]?.color}
                />
              ))}
            </ol>
          </div>
        </aside>
      </div>
    </AppShell>
  );
}

function TimelineItem({ time, title, note, color }: { time: string; title: string; note?: string; color?: string }) {
  return (
    <li className="flex gap-3">
      <div className="flex flex-col items-center">
        <span className="h-2.5 w-2.5 rounded-full mt-1.5" style={{ backgroundColor: color ?? "var(--muted-foreground)" }} />
        <span className="w-px flex-1 bg-border mt-1" />
      </div>
      <div className="flex-1 pb-3">
        <p className="text-sm font-semibold">{title}</p>
        <p className="text-xs text-muted-foreground">{formatRelativeTime(time)}</p>
        {note && <p className="text-xs mt-1">{note}</p>}
      </div>
    </li>
  );
}
