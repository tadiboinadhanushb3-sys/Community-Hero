import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { AppShell } from "@/components/AppShell";
import { supabase } from "@/integrations/supabase/client";
import { CATEGORY_META, SEVERITY_META, STATUS_META, formatRelativeTime, type IssueCategory, type IssueStatus } from "@/lib/issues";
import { IssueThumb } from "@/components/IssueThumb";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { CheckCircle2, MapPin, Search, ThumbsUp } from "lucide-react";

export const Route = createFileRoute("/_authenticated/issues/")({
  head: () => ({ meta: [{ title: "Issues — Community Hero" }] }),
  component: IssuesIndex,
});

function IssuesIndex() {
  const [q, setQ] = useState("");
  const [cat, setCat] = useState<IssueCategory | "all">("all");
  const [stat, setStat] = useState<IssueStatus | "all">("all");

  const { data: issues, isLoading } = useQuery({
    queryKey: ["issues", cat, stat],
    queryFn: async () => {
      let query = supabase.from("issues").select("*").order("created_at", { ascending: false }).limit(60);
      if (cat !== "all") query = query.eq("category", cat);
      if (stat !== "all") query = query.eq("status", stat);
      const { data, error } = await query;
      if (error) throw error;
      return data ?? [];
    },
  });

  const filtered = (issues ?? []).filter((i) =>
    q ? `${i.title} ${i.description} ${i.address ?? ""}`.toLowerCase().includes(q.toLowerCase()) : true,
  );

  return (
    <AppShell>
      <div className="mb-6">
        <h1 className="font-display text-3xl font-bold">Community issues</h1>
        <p className="text-muted-foreground mt-1">Verify, comment and track reports near you.</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-[1fr,180px,180px] gap-2 mb-6">
        <div className="relative">
          <Search className="absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search issues..." className="pl-9" />
        </div>
        <Select value={cat} onValueChange={(v) => setCat(v as IssueCategory | "all")}>
          <SelectTrigger><SelectValue placeholder="Category" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All categories</SelectItem>
            {(Object.keys(CATEGORY_META) as IssueCategory[]).map((k) => (
              <SelectItem key={k} value={k}>{CATEGORY_META[k].emoji} {CATEGORY_META[k].label}</SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Select value={stat} onValueChange={(v) => setStat(v as IssueStatus | "all")}>
          <SelectTrigger><SelectValue placeholder="Status" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All statuses</SelectItem>
            {(Object.keys(STATUS_META) as IssueStatus[]).map((k) => (
              <SelectItem key={k} value={k}>{STATUS_META[k].label}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {isLoading ? (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {Array.from({ length: 6 }).map((_, i) => (
            <div key={i} className="rounded-2xl bg-card border h-72 animate-pulse" />
          ))}
        </div>
      ) : filtered.length === 0 ? (
        <div className="rounded-2xl border-2 border-dashed p-12 text-center">
          <p className="font-semibold">No issues match your filters</p>
          <p className="text-sm text-muted-foreground mt-1">Try clearing filters or be the first to report.</p>
        </div>
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {filtered.map((issue) => {
            const cat = CATEGORY_META[issue.category];
            const sev = SEVERITY_META[issue.severity];
            const stat = STATUS_META[issue.status];
            return (
              <Link
                key={issue.id}
                to="/issues/$id"
                params={{ id: issue.id }}
                className="group rounded-2xl bg-card shadow-card hover:shadow-elevated transition-all overflow-hidden border"
              >
                <div className="aspect-video relative overflow-hidden bg-muted">
                  <IssueThumb path={issue.image_url} alt={issue.title} />
                  <div className="absolute top-2 left-2 flex gap-1.5">
                    <span className="rounded-full bg-background/95 backdrop-blur px-2.5 py-1 text-[11px] font-semibold">{cat.emoji} {cat.label}</span>
                  </div>
                  <div className="absolute top-2 right-2">
                    <span className="rounded-full px-2.5 py-1 text-[11px] font-semibold text-white" style={{ backgroundColor: sev.color }}>{sev.label}</span>
                  </div>
                </div>
                <div className="p-4">
                  <h3 className="font-semibold leading-tight line-clamp-1 group-hover:text-primary">{issue.title}</h3>
                  {issue.address && (
                    <p className="mt-1 text-xs text-muted-foreground line-clamp-1 inline-flex items-center gap-1">
                      <MapPin className="h-3 w-3" /> {issue.address}
                    </p>
                  )}
                  <div className="mt-3 flex items-center justify-between text-xs">
                    <span className="inline-flex items-center gap-1.5">
                      <span className="h-2 w-2 rounded-full" style={{ backgroundColor: stat.color }} />
                      <span className="font-medium">{stat.label}</span>
                    </span>
                    <div className="flex items-center gap-3 text-muted-foreground">
                      <span className="inline-flex items-center gap-1"><ThumbsUp className="h-3 w-3" /> {issue.verification_count}</span>
                      <span>{formatRelativeTime(issue.created_at)}</span>
                    </div>
                  </div>
                </div>
              </Link>
            );
          })}
        </div>
      )}
    </AppShell>
  );
}
