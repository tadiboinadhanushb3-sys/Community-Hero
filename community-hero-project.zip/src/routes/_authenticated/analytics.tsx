import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { AppShell } from "@/components/AppShell";
import { supabase } from "@/integrations/supabase/client";
import { CATEGORY_META, STATUS_META, type IssueCategory, type IssueStatus } from "@/lib/issues";
import { BarChart, Bar, ResponsiveContainer, XAxis, YAxis, Tooltip, PieChart, Pie, Cell, LineChart, Line, CartesianGrid } from "recharts";
import { TrendingUp, CheckCircle2, AlertCircle, Users } from "lucide-react";

export const Route = createFileRoute("/_authenticated/analytics")({
  head: () => ({ meta: [{ title: "Analytics — Community Hero" }] }),
  component: AnalyticsPage,
});

function AnalyticsPage() {
  const { data } = useQuery({
    queryKey: ["analytics"],
    queryFn: async () => {
      const { data: issues } = await supabase.from("issues").select("category,status,severity,created_at");
      const { count: contributors } = await supabase.from("profiles").select("id", { count: "exact", head: true });
      return { issues: issues ?? [], contributors: contributors ?? 0 };
    },
  });

  const issues = data?.issues ?? [];
  const total = issues.length;
  const resolved = issues.filter((i) => i.status === "resolved").length;
  const active = total - resolved;

  const byCategory = (Object.keys(CATEGORY_META) as IssueCategory[]).map((k) => ({
    name: CATEGORY_META[k].label,
    value: issues.filter((i) => i.category === k).length,
  }));

  const byStatus = (Object.keys(STATUS_META) as IssueStatus[]).map((k) => ({
    name: STATUS_META[k].label,
    value: issues.filter((i) => i.status === k).length,
    color: STATUS_META[k].color,
  }));

  // Last 14 days trend
  const days = Array.from({ length: 14 }, (_, i) => {
    const d = new Date();
    d.setDate(d.getDate() - (13 - i));
    d.setHours(0, 0, 0, 0);
    return d;
  });
  const trend = days.map((d) => {
    const next = new Date(d);
    next.setDate(next.getDate() + 1);
    return {
      day: d.toLocaleDateString(undefined, { month: "short", day: "numeric" }),
      reports: issues.filter((i) => {
        const t = new Date(i.created_at).getTime();
        return t >= d.getTime() && t < next.getTime();
      }).length,
    };
  });

  const COLORS = ["#f59e0b", "#3b82f6", "#10b981", "#ef4444", "#8b5cf6", "#6b7280"];

  return (
    <AppShell>
      <div className="mb-6">
        <h1 className="font-display text-3xl font-bold">Community analytics</h1>
        <p className="text-muted-foreground mt-1">Trends, participation, and resolution rates.</p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-6">
        <Kpi icon={TrendingUp} label="Total reports" value={total} />
        <Kpi icon={CheckCircle2} label="Resolved" value={resolved} sub={total ? `${Math.round((resolved / total) * 100)}% rate` : ""} />
        <Kpi icon={AlertCircle} label="Active" value={active} />
        <Kpi icon={Users} label="Contributors" value={data?.contributors ?? 0} />
      </div>

      <div className="grid lg:grid-cols-2 gap-4">
        <Panel title="Reports — last 14 days">
          <ResponsiveContainer width="100%" height={260}>
            <LineChart data={trend}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" opacity={0.3} />
              <XAxis dataKey="day" fontSize={11} tick={{ fill: "var(--muted-foreground)" }} />
              <YAxis fontSize={11} tick={{ fill: "var(--muted-foreground)" }} allowDecimals={false} />
              <Tooltip contentStyle={{ borderRadius: 8, border: "1px solid var(--border)" }} />
              <Line type="monotone" dataKey="reports" stroke="oklch(0.78 0.16 70)" strokeWidth={3} dot={{ r: 3 }} />
            </LineChart>
          </ResponsiveContainer>
        </Panel>

        <Panel title="By status">
          <ResponsiveContainer width="100%" height={260}>
            <PieChart>
              <Pie data={byStatus.filter((s) => s.value > 0)} dataKey="value" nameKey="name" innerRadius={50} outerRadius={90} paddingAngle={3}>
                {byStatus.map((entry, i) => <Cell key={i} fill={entry.color} />)}
              </Pie>
              <Tooltip contentStyle={{ borderRadius: 8, border: "1px solid var(--border)" }} />
            </PieChart>
          </ResponsiveContainer>
          <div className="flex flex-wrap gap-3 justify-center mt-2 text-xs">
            {byStatus.map((s) => (
              <span key={s.name} className="inline-flex items-center gap-1.5">
                <span className="h-2.5 w-2.5 rounded-full" style={{ backgroundColor: s.color }} />
                {s.name} ({s.value})
              </span>
            ))}
          </div>
        </Panel>

        <Panel title="By category" className="lg:col-span-2">
          <ResponsiveContainer width="100%" height={280}>
            <BarChart data={byCategory}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" opacity={0.3} />
              <XAxis dataKey="name" fontSize={11} tick={{ fill: "var(--muted-foreground)" }} />
              <YAxis fontSize={11} tick={{ fill: "var(--muted-foreground)" }} allowDecimals={false} />
              <Tooltip contentStyle={{ borderRadius: 8, border: "1px solid var(--border)" }} />
              <Bar dataKey="value" radius={[8, 8, 0, 0]}>
                {byCategory.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </Panel>
      </div>
    </AppShell>
  );
}

function Kpi({ icon: Icon, label, value, sub }: { icon: any; label: string; value: number; sub?: string }) {
  return (
    <div className="rounded-2xl bg-card border p-4 shadow-card">
      <div className="flex items-center justify-between">
        <span className="text-xs text-muted-foreground font-medium uppercase tracking-wider">{label}</span>
        <Icon className="h-4 w-4 text-muted-foreground" />
      </div>
      <p className="mt-2 font-display text-3xl font-bold tabular-nums">{value.toLocaleString()}</p>
      {sub && <p className="text-xs text-muted-foreground mt-0.5">{sub}</p>}
    </div>
  );
}

function Panel({ title, children, className }: { title: string; children: React.ReactNode; className?: string }) {
  return (
    <div className={`rounded-2xl bg-card border shadow-card p-5 ${className ?? ""}`}>
      <h3 className="font-display font-bold mb-3">{title}</h3>
      {children}
    </div>
  );
}
