import { createFileRoute, Link, redirect } from "@tanstack/react-router";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { AppShell } from "@/components/AppShell";
import { supabase } from "@/integrations/supabase/client";
import { CATEGORY_META, SEVERITY_META, STATUS_META, formatRelativeTime, type IssueStatus } from "@/lib/issues";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Shield } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated/admin")({
  head: () => ({ meta: [{ title: "Admin — Community Hero" }] }),
  beforeLoad: async () => {
    const { data } = await supabase.auth.getUser();
    if (!data.user) throw redirect({ to: "/auth" });
    const { data: roles } = await supabase.from("user_roles").select("role").eq("user_id", data.user.id);
    if (!roles?.some((r) => r.role === "admin")) throw redirect({ to: "/dashboard" });
  },
  component: AdminPage,
});

function AdminPage() {
  const qc = useQueryClient();
  const { data: issues, isLoading } = useQuery({
    queryKey: ["admin-issues"],
    queryFn: async () => {
      const { data, error } = await supabase.from("issues").select("*").order("created_at", { ascending: false }).limit(200);
      if (error) throw error;
      return data ?? [];
    },
  });

  const statusMutation = useMutation({
    mutationFn: async ({ id, status }: { id: string; status: IssueStatus }) => {
      const { data: u } = await supabase.auth.getUser();
      if (!u.user) throw new Error("Not signed in");
      const { error } = await supabase.from("issues").update({ status, updated_at: new Date().toISOString() }).eq("id", id);
      if (error) throw error;
      await supabase.from("status_updates").insert({ issue_id: id, changed_by: u.user.id, to_status: status, note: `Admin set status: ${status}` });
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["admin-issues"] });
      toast.success("Updated");
    },
    onError: (e) => toast.error(e instanceof Error ? e.message : "Failed"),
  });

  return (
    <AppShell>
      <div className="mb-6 flex items-center gap-3">
        <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary text-primary-foreground">
          <Shield className="h-5 w-5" />
        </div>
        <div>
          <h1 className="font-display text-3xl font-bold">Admin console</h1>
          <p className="text-muted-foreground text-sm">Manage all reported issues</p>
        </div>
      </div>

      <div className="rounded-2xl bg-card border shadow-card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-secondary text-xs uppercase tracking-wider text-muted-foreground">
              <tr>
                <th className="text-left px-4 py-3">Issue</th>
                <th className="text-left px-4 py-3 hidden md:table-cell">Category</th>
                <th className="text-left px-4 py-3 hidden md:table-cell">Severity</th>
                <th className="text-left px-4 py-3 hidden lg:table-cell">Reported</th>
                <th className="text-left px-4 py-3">Status</th>
              </tr>
            </thead>
            <tbody>
              {isLoading && (
                <tr><td colSpan={5} className="text-center py-10 text-muted-foreground">Loading...</td></tr>
              )}
              {issues?.map((i) => (
                <tr key={i.id} className="border-t hover:bg-secondary/50">
                  <td className="px-4 py-3">
                    <Link to="/issues/$id" params={{ id: i.id }} className="font-semibold hover:text-primary line-clamp-1">{i.title}</Link>
                    {i.address && <p className="text-xs text-muted-foreground line-clamp-1">{i.address}</p>}
                  </td>
                  <td className="px-4 py-3 hidden md:table-cell">{CATEGORY_META[i.category].emoji} {CATEGORY_META[i.category].label}</td>
                  <td className="px-4 py-3 hidden md:table-cell">
                    <span className="rounded-full px-2 py-0.5 text-xs font-semibold text-white" style={{ backgroundColor: SEVERITY_META[i.severity].color }}>
                      {SEVERITY_META[i.severity].label}
                    </span>
                  </td>
                  <td className="px-4 py-3 hidden lg:table-cell text-muted-foreground">{formatRelativeTime(i.created_at)}</td>
                  <td className="px-4 py-3">
                    <Select value={i.status} onValueChange={(v) => statusMutation.mutate({ id: i.id, status: v as IssueStatus })}>
                      <SelectTrigger className="w-36 h-8 text-xs"><SelectValue /></SelectTrigger>
                      <SelectContent>
                        {(Object.keys(STATUS_META) as IssueStatus[]).map((k) => (
                          <SelectItem key={k} value={k}>{STATUS_META[k].label}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </td>
                </tr>
              ))}
              {!isLoading && issues?.length === 0 && (
                <tr><td colSpan={5} className="text-center py-10 text-muted-foreground">No issues yet</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </AppShell>
  );
}
