import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useEffect, useRef, useState } from "react";
import { AppShell } from "@/components/AppShell";
import { supabase } from "@/integrations/supabase/client";
import { CATEGORY_META, SEVERITY_META } from "@/lib/issues";
import { Loader2, MapPin } from "lucide-react";
import { getMapsApiKey } from "@/lib/maps.functions";

export const Route = createFileRoute("/_authenticated/map")({
  head: () => ({ meta: [{ title: "Map — Community Hero" }] }),
  component: MapPage,
});

declare global {
  interface Window { google?: any }
}

function loadGoogleMaps(apiKey: string): Promise<void> {
  return new Promise((resolve, reject) => {
    if (window.google?.maps) return resolve();
    const existing = document.getElementById("gmaps-sdk");
    if (existing) {
      existing.addEventListener("load", () => resolve());
      existing.addEventListener("error", () => reject(new Error("Failed to load Google Maps")));
      return;
    }
    const s = document.createElement("script");
    s.id = "gmaps-sdk";
    s.src = `https://maps.googleapis.com/maps/api/js?key=${apiKey}&libraries=places`;
    s.async = true;
    s.defer = true;
    s.onload = () => resolve();
    s.onerror = () => reject(new Error("Failed to load Google Maps"));
    document.head.appendChild(s);
  });
}

function MapPage() {
  const navigate = useNavigate();
  const mapRef = useRef<HTMLDivElement>(null);
  const [ready, setReady] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const { data: issues } = useQuery({
    queryKey: ["map-issues"],
    queryFn: async () => {
      const { data } = await supabase
        .from("issues")
        .select("id,title,category,severity,status,latitude,longitude,address")
        .not("latitude", "is", null)
        .not("longitude", "is", null)
        .limit(500);
      return data ?? [];
    },
  });

  useEffect(() => {
    (async () => {
      try {
        const { key } = await getMapsApiKey();
        if (!key) {
          setError("Google Maps API key not configured.");
          return;
        }
        await loadGoogleMaps(key);
        setReady(true);
      } catch (e) {
        setError(e instanceof Error ? e.message : "Map load failed");
      }
    })();
  }, []);

  useEffect(() => {
    if (!ready || !mapRef.current || !window.google) return;

    const defaultCenter = { lat: 28.6139, lng: 77.209 };
    const map = new window.google.maps.Map(mapRef.current, {
      center: defaultCenter,
      zoom: 12,
      mapTypeControl: false,
      streetViewControl: false,
      fullscreenControl: false,
      styles: [
        { featureType: "poi", stylers: [{ visibility: "off" }] },
        { featureType: "transit", stylers: [{ visibility: "off" }] },
      ],
    });

    navigator.geolocation?.getCurrentPosition((p) => {
      map.setCenter({ lat: p.coords.latitude, lng: p.coords.longitude });
      map.setZoom(14);
    });

    const bounds = new window.google.maps.LatLngBounds();
    let added = 0;

    (issues ?? []).forEach((issue) => {
      if (issue.latitude == null || issue.longitude == null) return;
      const pos = { lat: Number(issue.latitude), lng: Number(issue.longitude) };
      const color = SEVERITY_META[issue.severity].color;
      const marker = new window.google.maps.Marker({
        position: pos,
        map,
        title: issue.title,
        icon: {
          path: window.google.maps.SymbolPath.CIRCLE,
          scale: 10,
          fillColor: getCssColor(color),
          fillOpacity: 0.95,
          strokeWeight: 2,
          strokeColor: "#fff",
        },
      });

      const info = new window.google.maps.InfoWindow({
        content: `<div style="font-family:Inter,sans-serif;max-width:220px"><div style="font-weight:700;font-size:14px;margin-bottom:4px">${escapeHtml(issue.title)}</div><div style="font-size:12px;color:#666">${CATEGORY_META[issue.category].emoji} ${CATEGORY_META[issue.category].label} • ${SEVERITY_META[issue.severity].label}</div>${issue.address ? `<div style="font-size:11px;color:#888;margin-top:4px">${escapeHtml(issue.address)}</div>` : ""}<button id="open-${issue.id}" style="margin-top:8px;background:#1e1b4b;color:#fff;border:0;border-radius:6px;padding:6px 10px;font-size:12px;font-weight:600;cursor:pointer">Open</button></div>`,
      });

      marker.addListener("click", () => {
        info.open(map, marker);
        setTimeout(() => {
          document.getElementById(`open-${issue.id}`)?.addEventListener("click", () => navigate({ to: "/issues/$id", params: { id: issue.id } }));
        }, 50);
      });

      bounds.extend(pos);
      added++;
    });
    if (added > 1) map.fitBounds(bounds, 60);
  }, [ready, issues, navigate]);

  return (
    <AppShell>
      <div className="mb-4">
        <h1 className="font-display text-3xl font-bold">Live issue map</h1>
        <p className="text-muted-foreground mt-1">Tap a pin to view details. Colors reflect severity.</p>
      </div>

      <div className="relative rounded-2xl overflow-hidden border shadow-card" style={{ height: "70vh", minHeight: "480px" }}>
        {error ? (
          <div className="flex h-full items-center justify-center p-6 text-center bg-muted">
            <div>
              <MapPin className="h-10 w-10 text-muted-foreground mx-auto" />
              <p className="mt-2 font-semibold">{error}</p>
            </div>
          </div>
        ) : !ready ? (
          <div className="flex h-full items-center justify-center bg-muted"><Loader2 className="h-6 w-6 animate-spin" /></div>
        ) : null}
        <div ref={mapRef} className="absolute inset-0" />
      </div>

      <div className="mt-4 flex flex-wrap gap-3 text-xs">
        {(Object.keys(SEVERITY_META) as Array<keyof typeof SEVERITY_META>).map((k) => (
          <span key={k} className="inline-flex items-center gap-1.5">
            <span className="h-3 w-3 rounded-full" style={{ backgroundColor: SEVERITY_META[k].color }} />
            {SEVERITY_META[k].label}
          </span>
        ))}
      </div>
    </AppShell>
  );
}

function escapeHtml(s: string) {
  return s.replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]!));
}

function getCssColor(varRef: string): string {
  // CSS var fallback to a sensible color; Google Maps needs concrete colors.
  const map: Record<string, string> = {
    "var(--severity-low)": "#22c55e",
    "var(--severity-medium)": "#eab308",
    "var(--severity-high)": "#f97316",
    "var(--severity-critical)": "#dc2626",
  };
  return map[varRef] ?? "#6366f1";
}
