import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { AppShell } from "@/components/AppShell";
import { supabase } from "@/integrations/supabase/client";
import { CATEGORY_META, SEVERITY_META, STATUS_META, formatRelativeTime } from "@/lib/issues";
import { Plus, MapPin, TrendingUp, CheckCircle2, AlertTriangle, Users, ArrowRight, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ChatBot } from "@/components/ChatBot";
import { IssueThumb } from "@/components/IssueThumb";

export const Route = createFileRoute("/_authenticated/dashboard")({
  head: () => ({ meta: [{ title: "Dashboard — Community Hero" }] }),
  component: Dashboard,
});

function Dashboard() {
  const { data: stats } = useQuery({
    queryKey: ["dashboard-stats"],
    queryFn: async () => {
      const [total, resolved, urgent, contributors] = await Promise.all([
        supabase.from("issues").select("id", { count: "exact", head: true }),
        supabase.from("issues").select("id", { count: "exact", head: true }).eq("status", "resolved"),
        supabase.from("issues").select("id", { count: "exact", head: true }).in("severity", ["high", "critical"]).neq("status", "resolved"),
        supabase.from("profiles").select("id", { count: "exact", head: true }),
      ]);
      return {
        total: total.count ?? 0,
        resolved: resolved.count ?? 0,
        urgent: urgent.count ?? 0,
        contributors: contributors.count ?? 0,
      };
    },
  });

  const { data: nearby } = useQuery({
    queryKey: ["nearby-issues"],
    queryFn: async () => {
      const { data } = await supabase
        .from("issues")
        .select("*")
        .order("created_at", { ascending: false })
        .limit(6);
      return data ?? [];
    },
  });

  return (
    <AppShell>
      {/* Hero */}
      <section className="relative overflow-hidden rounded-3xl bg-gradient-hero p-6 md:p-10 text-white">
        <div className="absolute -top-20 -right-20 h-72 w-72 rounded-full bg-signal/20 blur-3xl" />
        <div className="absolute -bottom-20 -left-20 h-72 w-72 rounded-full bg-status-verified/20 blur-3xl" />
        <div className="relative max-w-2xl">
          <div className="inline-flex items-center gap-2 rounded-full bg-white/10 backdrop-blur px-3 py-1 text-xs font-medium">
            <span className="h-1.5 w-1.5 rounded-full bg-signal animate-pulse" />
            AI triage live
          </div>
          <h1 className="mt-4 font-display text-3xl md:text-5xl font-bold leading-tight">
            See it. Snap it. <span className="text-signal">Fix it.</span>
          </h1>
          <p className="mt-3 text-white/80 text-base md:text-lg max-w-lg">
            Report civic issues in seconds. Our AI triages severity, drafts the complaint, and routes it to the right authority.
          </p>
          <div className="mt-6 flex flex-wrap gap-3">
            <Link to="/report">
              <Button size="lg" className="bg-gradient-signal text-signal-foreground hover:opacity-90 shadow-glow font-semibold">
                <Plus className="h-5 w-5" /> Report an issue
              </Button>
            </Link>
            <Link to="/map">
              <Button size="lg" variant="outline" className="bg-white/10 border-white/20 text-white hover:bg-white/20">
                <MapPin className="h-5 w-5" /> Explore map
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="mt-6 grid grid-cols-2 md:grid-cols-4 gap-3">
        <StatTile icon={TrendingUp} label="Total reports" value={stats?.total ?? 0} accent="signal" />
        <StatTile icon={CheckCircle2} label="Resolved" value={stats?.resolved ?? 0} accent="status-resolved" />
        <StatTile icon={AlertTriangle} label="Urgent open" value={stats?.urgent ?? 0} accent="severity-high" />
        <StatTile icon={Users} label="Contributors" value={stats?.contributors ?? 0} accent="status-verified" />
      </section>

      {/* Nearby issues */}
      <section className="mt-8">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="font-display text-xl font-bold">Recent in your community</h2>
            <p className="text-sm text-muted-foreground">Latest reports from neighbors</p>
          </div>
          <Link to="/issues" className="text-sm text-primary font-medium inline-flex items-center gap-1 hover:gap-2 transition-all">
            See all <ArrowRight className="h-4 w-4" />
          </Link>
        </div>

        {nearby && nearby.length > 0 ? (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {nearby.map((issue) => {
              const cat = CATEGORY_META[issue.category];
              const sev = SEVERITY_META[issue.severity];
              const stat = STATUS_META[issue.status];
              return (
                <Link
                  key={issue.id}
                  to="/issues/$id"
                  params={{ id: issue.id }}
                  className="group rounded-2xl bg-card shadow-card hover:shadow-elevated transition-all overflow-hidden border"
                >
                  <div className="aspect-video relative overflow-hidden bg-muted">
                    <IssueThumb path={issue.image_url} alt={issue.title} />
                    <div className="absolute top-2 left-2 flex gap-1.5">
                      <span className="rounded-full bg-background/95 backdrop-blur px-2.5 py-1 text-[11px] font-semibold inline-flex items-center gap-1">
                        <span>{cat.emoji}</span> {cat.label}
                      </span>
                    </div>
                    <div className="absolute top-2 right-2">
                      <span
                        className="rounded-full px-2.5 py-1 text-[11px] font-semibold text-white"
                        style={{ backgroundColor: sev.color }}
                      >
                        {sev.label}
                      </span>
                    </div>
                  </div>
                  <div className="p-4">
                    <h3 className="font-semibold leading-tight line-clamp-1 group-hover:text-primary transition-colors">
                      {issue.title}
                    </h3>
                    <p className="mt-1 text-xs text-muted-foreground line-clamp-2">{issue.description}</p>
                    <div className="mt-3 flex items-center justify-between text-xs">
                      <span className="inline-flex items-center gap-1.5">
                        <span
                          className="h-2 w-2 rounded-full"
                          style={{ backgroundColor: stat.color }}
                        />
                        <span className="font-medium">{stat.label}</span>
                      </span>
                      <span className="text-muted-foreground">{formatRelativeTime(issue.created_at)}</span>
                    </div>
                  </div>
                </Link>
              );
            })}
          </div>
        ) : (
          <div className="rounded-2xl border-2 border-dashed p-10 text-center">
            <Sparkles className="h-10 w-10 text-muted-foreground mx-auto" />
            <p className="mt-3 font-semibold">No reports yet</p>
            <p className="text-sm text-muted-foreground">Be the first to report an issue in your neighborhood.</p>
            <Link to="/report">
              <Button className="mt-4 bg-gradient-signal text-signal-foreground">
                <Plus className="h-4 w-4" /> Report first issue
              </Button>
            </Link>
          </div>
        )}
      </section>

      <ChatBot />
    </AppShell>
  );
}

function StatTile({
  icon: Icon,
  label,
  value,
  accent,
}: {
  icon: React.ComponentType<{ className?: string }>;
  label: string;
  value: number;
  accent: string;
}) {
  return (
    <div className="rounded-2xl bg-card border p-4 shadow-card">
      <div className="flex items-center justify-between">
        <span className="text-xs text-muted-foreground font-medium uppercase tracking-wider">{label}</span>
        <div
          className="flex h-7 w-7 items-center justify-center rounded-lg"
          style={{ backgroundColor: `color-mix(in oklab, var(--${accent}) 15%, transparent)`, color: `var(--${accent})` }}
        >
          <Icon className="h-4 w-4" />
        </div>
      </div>
      <p className="mt-2 font-display text-3xl font-bold tabular-nums">{value.toLocaleString()}</p>
    </div>
  );
}
