import { createServerFn } from "@tanstack/react-start";
import { generateText, generateObject } from "ai";
import { z } from "zod";
import { createLovableAiGatewayProvider } from "@/lib/ai-gateway.server";

const AnalysisSchema = z.object({
  category: z.enum(["pothole", "garbage", "water_leakage", "streetlight", "infrastructure", "other"]),
  severity: z.enum(["low", "medium", "high", "critical"]),
  title: z.string().max(80),
  description: z.string().max(500),
  risks: z.array(z.string()).max(4),
  recommendation: z.string().max(300),
  estimated_repair_time: z.string().max(60),
  complaint_text: z.string().max(1200),
});

export type AiAnalysis = z.infer<typeof AnalysisSchema>;

const InputSchema = z.object({
  imageDataUrl: z.string().min(20),
  userNote: z.string().max(500).optional(),
});

export const analyzeIssueImage = createServerFn({ method: "POST" })
  .inputValidator((data: unknown) => InputSchema.parse(data))
  .handler(async ({ data }): Promise<{ analysis: AiAnalysis } | { error: string }> => {
    const key = process.env.LOVABLE_API_KEY;
    if (!key) return { error: "AI service is not configured." };

    try {
      const gateway = createLovableAiGatewayProvider(key);
      const model = gateway("google/gemini-2.5-flash");

      const result = await generateObject({
        model,
        schema: AnalysisSchema,
        messages: [
          {
            role: "system",
            content:
              "You are Community Hero AI, an expert civic-issue analyst. You analyze photos of public infrastructure problems and produce structured triage reports for municipal authorities. Be precise, factual, and action-oriented. Categories: pothole, garbage, water_leakage, streetlight, infrastructure, other. Severity scale: low (cosmetic), medium (degrades quality of life), high (immediate inconvenience or minor safety risk), critical (serious safety risk or service outage). Always write a professional complaint_text addressed 'To the concerned municipal authority,' that summarizes the issue, location context, severity, and a polite call to action.",
          },
          {
            role: "user",
            content: [
              {
                type: "text",
                text: `Analyze this civic issue photo and produce the triage report.${
                  data.userNote ? ` User note: ${data.userNote}` : ""
                }`,
              },
              { type: "image", image: data.imageDataUrl },
            ],
          },
        ],
      });

      return { analysis: result.object };
    } catch (err) {
      console.error("[analyzeIssueImage]", err);
      const message = err instanceof Error ? err.message : "Unknown error";
      if (message.includes("429")) return { error: "Rate limit reached. Try again in a moment." };
      if (message.includes("402")) return { error: "AI credits exhausted. Please add credits in workspace settings." };
      return { error: "AI analysis failed. Please try again." };
    }
  });

const ChatInputSchema = z.object({
  messages: z
    .array(
      z.object({
        role: z.enum(["user", "assistant"]),
        content: z.string().min(1).max(2000),
      }),
    )
    .min(1)
    .max(20),
  context: z
    .object({
      totalIssues: z.number(),
      activeIssues: z.number(),
      resolvedIssues: z.number(),
      urgentIssues: z.number(),
      recentIssues: z
        .array(
          z.object({
            title: z.string(),
            category: z.string(),
            severity: z.string(),
            status: z.string(),
            address: z.string().nullable(),
          }),
        )
        .max(10),
    })
    .optional(),
});

export const chatWithAssistant = createServerFn({ method: "POST" })
  .inputValidator((data: unknown) => ChatInputSchema.parse(data))
  .handler(async ({ data }): Promise<{ reply: string } | { error: string }> => {
    const key = process.env.LOVABLE_API_KEY;
    if (!key) return { error: "AI service is not configured." };

    try {
      const gateway = createLovableAiGatewayProvider(key);
      const model = gateway("google/gemini-2.5-flash");

      const contextBlock = data.context
        ? `\n\nLive community data:
- Total issues reported: ${data.context.totalIssues}
- Active issues: ${data.context.activeIssues}
- Resolved: ${data.context.resolvedIssues}
- Urgent (high/critical): ${data.context.urgentIssues}
- Recent issues: ${data.context.recentIssues
            .map(
              (i) =>
                `• ${i.title} (${i.category}, ${i.severity}, ${i.status})${i.address ? " @ " + i.address : ""}`,
            )
            .join("\n")}`
        : "";

      const result = await generateText({
        model,
        messages: [
          {
            role: "system",
            content: `You are Community Hero Assistant — a concise, helpful civic AI. You help citizens understand neighborhood issues, prioritize what's urgent, and guide them on how to report or verify problems. Be brief (2-4 sentences usually), warm, and action-oriented. Use markdown bullets when listing.${contextBlock}`,
          },
          ...data.messages,
        ],
      });

      return { reply: result.text };
    } catch (err) {
      console.error("[chatWithAssistant]", err);
      const message = err instanceof Error ? err.message : "Unknown error";
      if (message.includes("429")) return { error: "Rate limit reached. Try again in a moment." };
      if (message.includes("402")) return { error: "AI credits exhausted." };
      return { error: "Assistant unavailable." };
    }
  });
