import { supabase } from "@/integrations/supabase/client";

export type IssueCategory = "pothole" | "garbage" | "water_leakage" | "streetlight" | "infrastructure" | "other";
export type IssueSeverity = "low" | "medium" | "high" | "critical";
export type IssueStatus = "reported" | "verified" | "in_progress" | "resolved";

export const CATEGORY_META: Record<IssueCategory, { label: string; emoji: string; color: string }> = {
  pothole: { label: "Pothole", emoji: "🕳️", color: "var(--severity-high)" },
  garbage: { label: "Garbage", emoji: "🗑️", color: "var(--severity-medium)" },
  water_leakage: { label: "Water Leakage", emoji: "💧", color: "var(--status-verified)" },
  streetlight: { label: "Streetlight", emoji: "💡", color: "var(--signal)" },
  infrastructure: { label: "Infrastructure", emoji: "🏗️", color: "var(--muted-foreground)" },
  other: { label: "Other", emoji: "📍", color: "var(--muted-foreground)" },
};

export const SEVERITY_META: Record<IssueSeverity, { label: string; color: string }> = {
  low: { label: "Low", color: "var(--severity-low)" },
  medium: { label: "Medium", color: "var(--severity-medium)" },
  high: { label: "High", color: "var(--severity-high)" },
  critical: { label: "Critical", color: "var(--severity-critical)" },
};

export const STATUS_META: Record<IssueStatus, { label: string; color: string }> = {
  reported: { label: "Reported", color: "var(--status-reported)" },
  verified: { label: "Verified", color: "var(--status-verified)" },
  in_progress: { label: "In Progress", color: "var(--status-progress)" },
  resolved: { label: "Resolved", color: "var(--status-resolved)" },
};

const signedUrlCache = new Map<string, { url: string; expiresAt: number }>();

export async function getSignedImageUrl(path: string | null | undefined): Promise<string | null> {
  if (!path) return null;
  // Already a full URL
  if (/^https?:\/\//.test(path)) return path;

  const cached = signedUrlCache.get(path);
  if (cached && cached.expiresAt > Date.now()) return cached.url;

  const { data, error } = await supabase.storage.from("issue-images").createSignedUrl(path, 3600);
  if (error || !data) return null;
  signedUrlCache.set(path, { url: data.signedUrl, expiresAt: Date.now() + 50 * 60 * 1000 });
  return data.signedUrl;
}

export function formatRelativeTime(date: string | Date): string {
  const d = typeof date === "string" ? new Date(date) : date;
  const seconds = Math.floor((Date.now() - d.getTime()) / 1000);
  if (seconds < 60) return "just now";
  if (seconds < 3600) return `${Math.floor(seconds / 60)}m ago`;
  if (seconds < 86400) return `${Math.floor(seconds / 3600)}h ago`;
  if (seconds < 2592000) return `${Math.floor(seconds / 86400)}d ago`;
  return d.toLocaleDateString();
}
